# Crosshair.ps1
# PNG crosshair overlay with a GUI and INI-persisted settings.
#
#  - Put your .png crosshairs in a "crosshair" folder next to this script.
#  - Settings are saved to Crosshair.ini next to this script.
#  - Overlay is click-through, always-on-top, hidden from Alt+Tab.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
if ($PSScriptRoot) { $ScriptDir = $PSScriptRoot }
else { $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition }

$CrosshairDir = Join-Path $ScriptDir 'crosshair'
$IniPath      = Join-Path $ScriptDir 'Crosshair.ini'

if (-not (Test-Path $CrosshairDir)) {
    New-Item -Path $CrosshairDir -ItemType Directory -Force | Out-Null
}

# ----------------------------------------------------------------------------
# Layered (per-pixel alpha) click-through overlay window
# ----------------------------------------------------------------------------
$source = @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class CrosshairOverlay : Form
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct BLENDFUNCTION
    {
        public byte BlendOp;
        public byte BlendFlags;
        public byte SourceConstantAlpha;
        public byte AlphaFormat;
    }

    [DllImport("user32.dll", SetLastError = true)]
    static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref Point pptDst,
        ref Size psize, IntPtr hdcSrc, ref Point pptSrc, int crKey,
        ref BLENDFUNCTION pblend, int dwFlags);

    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hWnd);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
    [DllImport("gdi32.dll")]  static extern IntPtr CreateCompatibleDC(IntPtr hDC);
    [DllImport("gdi32.dll")]  static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")]  static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
    [DllImport("gdi32.dll")]  static extern bool DeleteObject(IntPtr hObject);

    [DllImport("user32.dll")]
    static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
        int x, int y, int cx, int cy, uint flags);

    private Bitmap current;
    private byte currentAlpha = 255;

    public int OffsetX = 0;
    public int OffsetY = 0;

    public CrosshairOverlay()
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        Size = new Size(1, 1);
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00080000; // WS_EX_LAYERED: per-pixel alpha
            cp.ExStyle |= 0x00000020; // WS_EX_TRANSPARENT: click-through
            cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE: never takes focus
            cp.ExStyle |= 0x00000080; // WS_EX_TOOLWINDOW: hidden from Alt+Tab
            return cp;
        }
    }

    // Replaces the drawn crosshair: any 32bpp ARGB bitmap (i.e. a user PNG).
    public void SetBitmap(Bitmap bitmap, byte opacity)
    {
        if (bitmap == null) return;

        if (current != null && !object.ReferenceEquals(current, bitmap))
        {
            current.Dispose();
        }
        current = bitmap;
        currentAlpha = opacity;

        if (!IsHandleCreated) CreateHandle();

        IntPtr screenDc = GetDC(IntPtr.Zero);
        IntPtr memDc = CreateCompatibleDC(screenDc);
        IntPtr hBitmap = IntPtr.Zero;
        IntPtr oldBitmap = IntPtr.Zero;

        try
        {
            hBitmap = bitmap.GetHbitmap(Color.FromArgb(0));
            oldBitmap = SelectObject(memDc, hBitmap);

            Size size = new Size(bitmap.Width, bitmap.Height);
            Point source = new Point(0, 0);
            Rectangle scr = Screen.PrimaryScreen.Bounds;
            Point topPos = new Point(
                scr.Left + (scr.Width - size.Width) / 2 + OffsetX,
                scr.Top + (scr.Height - size.Height) / 2 + OffsetY);

            BLENDFUNCTION blend = new BLENDFUNCTION();
            blend.BlendOp = 0;                      // AC_SRC_OVER
            blend.BlendFlags = 0;
            blend.SourceConstantAlpha = opacity;    // global opacity
            blend.AlphaFormat = 1;                  // AC_SRC_ALPHA

            UpdateLayeredWindow(Handle, screenDc, ref topPos, ref size,
                memDc, ref source, 0, ref blend, 2 /* ULW_ALPHA */);
        }
        finally
        {
            ReleaseDC(IntPtr.Zero, screenDc);
            if (hBitmap != IntPtr.Zero)
            {
                SelectObject(memDc, oldBitmap);
                DeleteObject(hBitmap);
            }
            DeleteDC(memDc);
        }
    }

    public void Refresh(byte opacity)
    {
        if (current != null) SetBitmap(current, opacity);
    }

    public void Recenter()
    {
        if (current != null) SetBitmap(current, currentAlpha);
    }

    public void KeepOnTop()
    {
        if (IsHandleCreated)
        {
            SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0013);
        }
    }
}
'@

if (-not ('CrosshairOverlay' -as [type])) {
    Add-Type -TypeDefinition $source `
        -ReferencedAssemblies System.Windows.Forms, System.Drawing
}

# ----------------------------------------------------------------------------
# INI helpers
# ----------------------------------------------------------------------------
function Read-Ini {
    param([string]$Path)
    $result = @{}
    if (Test-Path $Path) {
        foreach ($line in Get-Content -Path $Path -Encoding UTF8) {
            $t = $line.Trim()
            if ($t -eq '' -or $t.StartsWith(';') -or $t.StartsWith('[')) { continue }
            $i = $t.IndexOf('=')
            if ($i -gt 0) {
                $result[$t.Substring(0, $i).Trim()] = $t.Substring($i + 1).Trim()
            }
        }
    }
    return $result
}

function Write-Ini {
    param([string]$Path, [hashtable]$Data)
    $lines = @('[Crosshair]')
    foreach ($k in ($Data.Keys | Sort-Object)) { $lines += ("{0}={1}" -f $k, $Data[$k]) }
    Set-Content -Path $Path -Value $lines -Encoding UTF8
}

$ini = Read-Ini -Path $IniPath

function Get-Setting {
    param($Key, $Default)
    if ($ini.ContainsKey($Key) -and $ini[$Key] -ne '') { return $ini[$Key] }
    return $Default
}

$Settings = @{
    Image   = [string](Get-Setting 'Image'   '')
    Opacity = [int]   (Get-Setting 'Opacity' 100)
    Scale   = [int]   (Get-Setting 'Scale'   100)
    OffsetX = [int]   (Get-Setting 'OffsetX' 0)
    OffsetY = [int]   (Get-Setting 'OffsetY' 0)
}

# ----------------------------------------------------------------------------
# Image helpers
# ----------------------------------------------------------------------------
function Get-CrosshairFiles {
    if (-not (Test-Path $CrosshairDir)) { return @() }
    Get-ChildItem -Path $CrosshairDir -File |
        Where-Object { $_.Extension -match '^\.(png|bmp|gif)$' } |
        Sort-Object Name
}

# Fallback crosshair drawn in code (used when the folder has no PNG yet).
function New-DefaultCrosshairBitmap {
    $bmp = New-Object System.Drawing.Bitmap 49, 49, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $outline = New-Object System.Drawing.Pen ([System.Drawing.Color]::Black), 5
    $cross   = New-Object System.Drawing.Pen ([System.Drawing.Color]::Red), 2
    $g.DrawLine($outline, 24, 13, 24, 35)
    $g.DrawLine($outline, 13, 24, 35, 24)
    $g.DrawLine($cross,   24, 13, 24, 35)
    $g.DrawLine($cross,   13, 24, 35, 24)
    $outline.Dispose(); $cross.Dispose(); $g.Dispose()
    return $bmp
}

function New-ScaledBitmap {
    param([System.Drawing.Image]$Image, [int]$Percent)

    $w = [Math]::Max(1, [int]([Math]::Round($Image.Width  * $Percent / 100)))
    $h = [Math]::Max(1, [int]([Math]::Round($Image.Height * $Percent / 100)))

    $bmp = New-Object System.Drawing.Bitmap $w, $h, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode  = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode    = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $g.Clear([System.Drawing.Color]::Transparent)
    $g.DrawImage($Image, 0, 0, $w, $h)
    $g.Dispose()
    return $bmp
}

# Loads a file without locking it on disk.
function Load-ImageUnlocked {
    param([string]$Path)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        $ms = New-Object System.IO.MemoryStream (,$bytes)
        $img = [System.Drawing.Image]::FromStream($ms)
        $clone = New-Object System.Drawing.Bitmap $img
        $img.Dispose(); $ms.Dispose()
        return $clone
    } catch { return $null }
}

# ----------------------------------------------------------------------------
# Overlay instance
# ----------------------------------------------------------------------------
$overlay = New-Object CrosshairOverlay
$sourceImage = $null

function Apply-Overlay {
    $img = $script:sourceImage
    if (-not $img) { $img = New-DefaultCrosshairBitmap; $script:sourceImage = $img }

    $scaled = New-ScaledBitmap -Image $img -Percent $Settings.Scale
    $alpha  = [byte]([Math]::Round(255 * ($Settings.Opacity / 100.0)))

    $overlay.OffsetX = $Settings.OffsetX
    $overlay.OffsetY = $Settings.OffsetY
    $overlay.SetBitmap($scaled, $alpha)
    $overlay.KeepOnTop()
}

function Select-CrosshairImage {
    param([string]$Path)
    if ($Path -and (Test-Path $Path)) {
        $loaded = Load-ImageUnlocked -Path $Path
        if ($loaded) {
            if ($script:sourceImage) { $script:sourceImage.Dispose() }
            $script:sourceImage = $loaded
            $Settings.Image = $Path
            return $true
        }
    }
    return $false
}

# ----------------------------------------------------------------------------
# Modern settings GUI
# ----------------------------------------------------------------------------
$clrBack   = [System.Drawing.Color]::FromArgb(24, 24, 28)
$clrPanel  = [System.Drawing.Color]::FromArgb(34, 34, 40)
$clrText   = [System.Drawing.Color]::FromArgb(235, 235, 240)
$clrMuted  = [System.Drawing.Color]::FromArgb(150, 150, 160)
$clrAccent = [System.Drawing.Color]::FromArgb(0, 120, 215)
$fontUI    = New-Object System.Drawing.Font 'Segoe UI', 9
$fontHead  = New-Object System.Drawing.Font 'Segoe UI Semibold', 14

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Crosshair Settings'
$form.ClientSize = New-Object System.Drawing.Size 620, 440
$form.BackColor = $clrBack
$form.ForeColor = $clrText
$form.Font = $fontUI
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Crosshair Overlay'
$title.Font = $fontHead
$title.ForeColor = $clrText
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point 20, 16
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "PNG files found in: $CrosshairDir"
$subtitle.ForeColor = $clrMuted
$subtitle.AutoSize = $true
$subtitle.Location = New-Object System.Drawing.Point 22, 44
$form.Controls.Add($subtitle)

# --- list of crosshairs ---
$list = New-Object System.Windows.Forms.ListBox
$list.Location = New-Object System.Drawing.Point 20, 72
$list.Size = New-Object System.Drawing.Size 250, 250
$list.BackColor = $clrPanel
$list.ForeColor = $clrText
$list.BorderStyle = 'None'
$list.IntegralHeight = $false
$form.Controls.Add($list)

# --- preview ---
$previewPanel = New-Object System.Windows.Forms.Panel
$previewPanel.Location = New-Object System.Drawing.Point 290, 72
$previewPanel.Size = New-Object System.Drawing.Size 150, 150
$previewPanel.BackColor = $clrPanel
$form.Controls.Add($previewPanel)

$preview = New-Object System.Windows.Forms.PictureBox
$preview.Dock = 'Fill'
$preview.SizeMode = 'Zoom'
$preview.BackColor = $clrPanel
$previewPanel.Controls.Add($preview)

$previewLbl = New-Object System.Windows.Forms.Label
$previewLbl.Text = 'Preview'
$previewLbl.ForeColor = $clrMuted
$previewLbl.AutoSize = $true
$previewLbl.Location = New-Object System.Drawing.Point 292, 226
$form.Controls.Add($previewLbl)

function New-Slider {
    param($LabelText, $X, $Y, $Min, $Max, $Value, $Tick)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $LabelText
    $lbl.ForeColor = $clrMuted
    $lbl.AutoSize = $true
    $lbl.Location = New-Object System.Drawing.Point $X, $Y
    $form.Controls.Add($lbl)

    $val = New-Object System.Windows.Forms.Label
    $val.Text = "$Value"
    $val.ForeColor = $clrAccent
    $val.AutoSize = $true
    $val.Location = New-Object System.Drawing.Point ($X + 230), $Y
    $form.Controls.Add($val)

    $tb = New-Object System.Windows.Forms.TrackBar
    $tb.Location = New-Object System.Drawing.Point ($X - 6), ($Y + 18)
    $tb.Size = New-Object System.Drawing.Size 290, 40
    $tb.Minimum = $Min
    $tb.Maximum = $Max
    $tb.TickFrequency = $Tick
    $tb.Value = [Math]::Min([Math]::Max($Value, $Min), $Max)
    $tb.BackColor = $clrBack
    $form.Controls.Add($tb)

    return @{ Track = $tb; Value = $val }
}

$opacityCtl = New-Slider 'Opacity (%)' 20 340 5  100 $Settings.Opacity 5
$scaleCtl   = New-Slider 'Size (%)'    320 340 10 400 $Settings.Scale   25

$offXLbl = New-Object System.Windows.Forms.Label
$offXLbl.Text = 'Offset X / Y (px)'
$offXLbl.ForeColor = $clrMuted
$offXLbl.AutoSize = $true
$offXLbl.Location = New-Object System.Drawing.Point 460, 240
$form.Controls.Add($offXLbl)

$offX = New-Object System.Windows.Forms.NumericUpDown
$offX.Location = New-Object System.Drawing.Point 460, 262
$offX.Size = New-Object System.Drawing.Size 60, 24
$offX.Minimum = -4000; $offX.Maximum = 4000; $offX.Value = $Settings.OffsetX
$offX.BackColor = $clrPanel; $offX.ForeColor = $clrText; $offX.BorderStyle = 'None'
$form.Controls.Add($offX)

$offY = New-Object System.Windows.Forms.NumericUpDown
$offY.Location = New-Object System.Drawing.Point 528, 262
$offY.Size = New-Object System.Drawing.Size 60, 24
$offY.Minimum = -4000; $offY.Maximum = 4000; $offY.Value = $Settings.OffsetY
$offY.BackColor = $clrPanel; $offY.ForeColor = $clrText; $offY.BorderStyle = 'None'
$form.Controls.Add($offY)

function New-FlatButton {
    param($Text, $X, $Y, $W, $Accent = $false)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = New-Object System.Drawing.Point $X, $Y
    $b.Size = New-Object System.Drawing.Size $W, 32
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.ForeColor = $clrText
    if ($Accent) { $b.BackColor = $clrAccent } else { $b.BackColor = $clrPanel }
    $form.Controls.Add($b)
    return $b
}

$btnRefresh = New-FlatButton 'Refresh folder' 290 240 150
$btnImport  = New-FlatButton 'Import PNG...'  460 190 128
$btnOpen    = New-FlatButton 'Open folder'    460 152 128
$btnSave    = New-FlatButton 'Save && Hide'   20  398 150 $true
$btnHide    = New-FlatButton 'Hide crosshair' 180 398 150
$btnExit    = New-FlatButton 'Exit'           470 398 120

# ----------------------------------------------------------------------------
# GUI behaviour
# ----------------------------------------------------------------------------
$script:files = @()

function Refresh-List {
    $script:files = @(Get-CrosshairFiles)
    $list.Items.Clear()
    foreach ($f in $script:files) { [void]$list.Items.Add($f.Name) }
    if ($script:files.Count -eq 0) {
        [void]$list.Items.Add('(no images - built-in crosshair in use)')
        $list.Enabled = $false
    } else {
        $list.Enabled = $true
        $idx = 0
        if ($Settings.Image) {
            $match = 0
            for ($i = 0; $i -lt $script:files.Count; $i++) {
                if ($script:files[$i].FullName -eq $Settings.Image) { $match = $i }
            }
            $idx = $match
        }
        $list.SelectedIndex = $idx
    }
}

function Update-Preview {
    if ($script:sourceImage) {
        if ($preview.Image) { $preview.Image.Dispose() }
        $preview.Image = New-Object System.Drawing.Bitmap $script:sourceImage
    }
}

$list.Add_SelectedIndexChanged({
    if (-not $list.Enabled) { return }
    $i = $list.SelectedIndex
    if ($i -ge 0 -and $i -lt $script:files.Count) {
        if (Select-CrosshairImage -Path $script:files[$i].FullName) {
            Update-Preview
            Apply-Overlay
        }
    }
})

$opacityCtl.Track.Add_Scroll({
    $Settings.Opacity = $opacityCtl.Track.Value
    $opacityCtl.Value.Text = "$($Settings.Opacity)"
    Apply-Overlay
})

$scaleCtl.Track.Add_Scroll({
    $Settings.Scale = $scaleCtl.Track.Value
    $scaleCtl.Value.Text = "$($Settings.Scale)"
    Apply-Overlay
})

$offX.Add_ValueChanged({ $Settings.OffsetX = [int]$offX.Value; Apply-Overlay })
$offY.Add_ValueChanged({ $Settings.OffsetY = [int]$offY.Value; Apply-Overlay })

$btnRefresh.Add_Click({ Refresh-List })

$btnOpen.Add_Click({ Start-Process explorer.exe $CrosshairDir })

$btnImport.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Images (*.png;*.bmp;*.gif)|*.png;*.bmp;*.gif'
    $dlg.Multiselect = $true
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        foreach ($f in $dlg.FileNames) {
            Copy-Item -Path $f -Destination $CrosshairDir -Force -ErrorAction SilentlyContinue
        }
        Refresh-List
    }
})

function Save-Settings {
    Write-Ini -Path $IniPath -Data @{
        Image   = $Settings.Image
        Opacity = $Settings.Opacity
        Scale   = $Settings.Scale
        OffsetX = $Settings.OffsetX
        OffsetY = $Settings.OffsetY
    }
}

$btnSave.Add_Click({ Save-Settings; $form.Hide() })
$btnHide.Add_Click({
    if ($overlay.Visible) { $overlay.Hide(); $btnHide.Text = 'Show crosshair' }
    else { $overlay.Show(); Apply-Overlay; $btnHide.Text = 'Hide crosshair' }
})
$btnExit.Add_Click({ Save-Settings; $form.Close() })

# Closing the window only hides it - use the tray icon or Exit to quit.
$form.Add_FormClosing({
    param($s, $e)
    if ($e.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing -and $s.Visible) {
        Save-Settings
    }
})

# --- tray icon so the GUI can be reopened after hiding ---
$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = [System.Drawing.SystemIcons]::Application
$tray.Text = 'Crosshair Overlay'
$tray.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
[void]$menu.Items.Add('Settings', $null, { $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })
[void]$menu.Items.Add('Exit',     $null, { Save-Settings; $form.Close() })
$tray.ContextMenuStrip = $menu
$tray.Add_DoubleClick({ $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })

# ----------------------------------------------------------------------------
# Start-up
# ----------------------------------------------------------------------------
if (-not (Select-CrosshairImage -Path $Settings.Image)) {
    $first = @(Get-CrosshairFiles) | Select-Object -First 1
    if ($first) { [void](Select-CrosshairImage -Path $first.FullName) }
}

Refresh-List
Update-Preview
$overlay.Show()
Apply-Overlay

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    if ($overlay.Visible) { $overlay.Recenter(); $overlay.KeepOnTop() }
})

try {
    $timer.Start()
    [System.Windows.Forms.Application]::Run($form)
}
finally {
    $timer.Stop(); $timer.Dispose()
    $tray.Visible = $false; $tray.Dispose()
    if ($preview.Image) { $preview.Image.Dispose() }
    if ($script:sourceImage) { $script:sourceImage.Dispose() }
    $overlay.Dispose()
}
